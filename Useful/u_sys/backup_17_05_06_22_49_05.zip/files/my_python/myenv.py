import os,sys

os.chdir('D:\\files\\my_python\\exercise')

from  Useful.u_sys.usefultools import *

