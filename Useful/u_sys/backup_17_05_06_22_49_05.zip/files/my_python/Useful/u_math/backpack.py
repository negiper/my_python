#******************************
#背包问题：求出所有背包填充方案
#******************************
import math
import pdb

N = 5
S = 15
items = [2,3,5,7,8]
flags = [0,0,0,0,0]

def count_res():
    print 'Bag weight:', S
    print 'Items number:', N

    count = 0
    resCount = 0
    print int(math.pow(2,N))
    while (count < int(math.pow(2,N))):
        #生成所有组合的巧妙方法
        for i in range(N):
            if flags[i] == 0:
                flags[i] = 1
                continue
            else:
                flags[i] = 0
                break
        #pdb.set_trace()
        count += 1
        #print flags
        temp = 0
        '''
        for i in range(N):
            if flags[i] == 1:
                temp += items[i]
        '''
        #取出列表中某些元素的简单方法
        temp = sum([items[i] for i in [j for j in range(N) if flags[j]]])
        if temp == S:
            for j in range(N):
                if flags[j] == 1:
                    print items[j],
            print
            resCount += 1

    print 'Results: ', resCount
            

count_res()
